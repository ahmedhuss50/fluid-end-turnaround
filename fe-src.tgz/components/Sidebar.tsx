"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

function I({ d }: { d: React.ReactNode }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      {d}
    </svg>
  );
}

export default function Sidebar({ units, active, requests, awaitingSignoff, notifications, role }: { units: number; active: number; requests: number; awaitingSignoff: number; notifications: number; role?: string }) {
  const path = usePathname();
  const is = (href: string) =>
    href === "/" ? path === "/" : path.startsWith(href);

  const ICON = {
    dashboard: <><rect x="3" y="3" width="7" height="9" rx="1" /><rect x="14" y="3" width="7" height="5" rx="1" /><rect x="14" y="12" width="7" height="9" rx="1" /><rect x="3" y="16" width="7" height="5" rx="1" /></>,
    units: <><path d="M3 7l9-4 9 4-9 4-9-4Z" /><path d="M3 7v10l9 4 9-4V7" /><path d="M12 11v10" /></>,
    requests: <><path d="M9 4h6a1 1 0 0 1 1 1v1h2a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h2V5a1 1 0 0 1 1-1Z" /><path d="M9 6h6" /><path d="M9 12h6M9 16h4" /></>,
    plus: <><path d="M12 5v14" /><path d="M5 12h14" /></>,
    gauge: <><path d="M12 3a9 9 0 0 1 9 9" /><path d="M3 12a9 9 0 0 1 9-9" /><path d="M3 12a9 9 0 0 0 9 9 9 9 0 0 0 9-9" /><path d="M12 12l4-3" /><circle cx="12" cy="12" r="1.4" /></>,
    board: <><rect x="3" y="3" width="6" height="18" rx="1" /><rect x="10" y="3" width="6" height="12" rx="1" /><rect x="17" y="3" width="4" height="16" rx="1" /></>,
    handoff: <><path d="M7 8l-4 4 4 4" /><path d="M3 12h11" /><path d="M17 16l4-4-4-4" /><path d="M21 12H10" /></>,
    check: <><path d="M9 11l3 3L22 4" /><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" /></>,
    users: <><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></>,
  };

  const psiItems = [
    { href: "/", label: "Dashboard", count: active, icon: ICON.dashboard },
    { href: "/board", label: "Pipeline Board", count: null, icon: ICON.board },
    { href: "/units", label: "Fluid Ends", count: units, icon: ICON.units },
    { href: "/requests", label: "Repair Requests", count: requests, icon: ICON.requests },
    { href: "/handoffs", label: "Release / Receive", count: null, icon: ICON.handoff },
    { href: "/jobs/new", label: "New Work Order", count: null, icon: ICON.plus },
    { href: "/users", label: "Users & Access", count: null, icon: ICON.users },
  ];

  // Client view: submit + track + sign off + release.
  const clientItems = [
    { href: "/requests", label: "Submit / Track Requests", count: requests, icon: ICON.requests },
    { href: "/work-orders", label: "Work Orders", count: awaitingSignoff, icon: ICON.check },
    { href: "/notifications", label: "Notifications", count: notifications, icon: ICON.bell },
    { href: "/handoffs", label: "Release a Unit", count: null, icon: ICON.handoff },
    { href: "/units", label: "My Fluid Ends", count: units, icon: ICON.units },
  ];

  const items = role === "client" ? clientItems : psiItems;

  return (
    <aside className="sidebar">
      <div className="nav-label">Workspace</div>
      {items.map((it) => (
        <Link key={it.href} href={it.href} className={`side-link${is(it.href) ? " active" : ""}`}>
          <span className="si"><I d={it.icon} /></span>
          {it.label}
          {it.count != null && it.count > 0 && <span className="count">{it.count}</span>}
        </Link>
      ))}
    </aside>
  );
}
